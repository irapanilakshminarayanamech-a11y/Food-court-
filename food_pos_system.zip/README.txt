FOOD POS
1. Extract this ZIP.
2. Open index.html in Chrome/Edge.
3. Works on laptop and mobile browsers.
4. Features: menu, categories, cart, total, cash/UPI/card selection, print bill, kitchen orders, ready/close.
5. Data is stored locally in the browser. For multiple devices sharing the same live orders, a server/database is needed.
