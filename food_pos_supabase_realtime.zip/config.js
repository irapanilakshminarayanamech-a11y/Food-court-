// Paste your Supabase Project URL and Publishable Key here.
// Get them from Supabase Dashboard > Connect/API.
// NEVER put a service_role/secret key in this file.
window.SUPABASE_URL = "https://YOUR-PROJECT.supabase.co";
window.SUPABASE_PUBLISHABLE_KEY = "YOUR_SB_PUBLISHABLE_KEY";
