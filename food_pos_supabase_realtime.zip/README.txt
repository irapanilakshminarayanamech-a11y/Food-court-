FOOD POS — SUPABASE REAL-TIME VERSION

What this version does
- Mobile and laptop connect to the same Supabase database.
- Orders placed on one device appear in the kitchen/order screen on the other device.
- Kitchen can change New -> Preparing -> Ready -> Complete.
- Menu is stored centrally and can be edited.
- Email/password authentication.
- Cash / UPI / Card.
- Print bill.
- Realtime order updates using Supabase Postgres Changes.

SETUP

1) Create a Supabase project.
   Go to https://supabase.com/ and create a project.

2) Open SQL Editor in your project.
   Open setup.sql from this ZIP, paste the complete contents, and Run.

3) Create your staff login.
   In Supabase Dashboard -> Authentication -> Users, create a user with an email/password.
   Alternatively, the app's Create account button can register an account if your Auth settings allow it.

4) Get your Supabase connection details.
   Dashboard -> Connect / API.
   Copy:
   - Project URL
   - Publishable key (starts with sb_publishable_ on newer projects)
   DO NOT use a service_role/secret key in the browser.

5) Edit config.js:
   window.SUPABASE_URL = "https://YOUR-PROJECT.supabase.co";
   window.SUPABASE_PUBLISHABLE_KEY = "YOUR_SB_PUBLISHABLE_KEY";

6) Test locally.
   Do NOT double-click index.html if your browser blocks scripts. Use VS Code + Live Server, or:
      python -m http.server 5500
   Then open:
      http://localhost:5500

7) Put it online.
   You can deploy the folder to a static host such as Netlify, Vercel, GitHub Pages, or Cloudflare Pages.
   The same HTTPS website can then be opened on the laptop and Android phone.

8) Test real-time:
   - Open the POS URL on laptop and phone.
   - Log in on both.
   - Add an order on phone.
   - It should appear in Live Kitchen Orders on the laptop.
   - Change status on laptop; the other device refreshes automatically.

IMPORTANT SECURITY
- The browser must only contain the Supabase Project URL and publishable key.
- Never put a Supabase service_role/secret key into config.js.
- This starter policy lets every authenticated staff user manage the menu and orders. For a larger business, add staff roles and tighter RLS policies.

FILES
- index.html = complete POS UI/app
- config.js = your Supabase URL + publishable key
- setup.sql = database tables, RLS policies, seed menu, realtime publication
- README.txt = this guide
